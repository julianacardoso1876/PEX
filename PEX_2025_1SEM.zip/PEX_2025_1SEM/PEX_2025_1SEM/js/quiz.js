const perguntas = [
  {
    pergunta: "Big Data é apenas sobre grandes volumes de dados, não importando o tipo de dados.",
    resposta: false
  },
  {
    pergunta: "Big Data pode incluir dados estruturados, semiestruturados e não estruturados.",
    resposta: true
  },
  {
    pergunta: "A característica de volume em Big Data se refere à velocidade com que os dados são processados.",
    resposta: false
  },
  {
    pergunta: "A veracidade dos dados em Big Data é importante porque garante que os dados sejam confiáveis e precisos para tomar decisões.",
    resposta: true
  },
  {
    pergunta: "A variedade de Big Data diz respeito à quantidade de dados gerados a cada segundo.",
    resposta: false
  },
  {
    pergunta: "A análise de Big Data pode ajudar a prever comportamentos futuros e otimizar processos de negócios.",
    resposta: true
  },
  {
    pergunta: "A principal preocupação com Big Data é apenas o volume de dados que ele gera.",
    resposta: false
  },
  {
    pergunta: "O Spotify e a Netflix usam Big Data para recomendar filmes e músicas com base nos dados dos usuários.",
    resposta: true
  },
  {
    pergunta: "Manter a qualidade dos dados é um dos maiores desafios em Big Data.",
    resposta: true
  },
  {
    pergunta: "Armazenar grandes volumes de dados é sempre barato e fácil para as empresas.",
    resposta: false
  },
  {
    pergunta: "A LGPD foi criada para garantir os direitos das empresas sobre os dados pessoais dos usuários.",
    resposta: false
  },
  {
    pergunta: "A privacidade diferencial permite que os dados sejam analisados sem comprometer a privacidade individual.",
    resposta: true
  },
  {
    pergunta: "A pseudonimização é um processo irreversível de ocultação de dados pessoais.",
    resposta: false
  },
  {
    pergunta: "A ética de dados inclui princípios como a privacidade, a não discriminação e a liberdade de escolha.",
    resposta: true
  },
  {
    pergunta: "A anonimização garante proteção total e permanente dos dados no Big Data.",
    resposta: false
  },
  {
    pergunta: "A LGPD exige que empresas adotem medidas técnicas e administrativas para proteger os dados pessoais.",
    resposta: true
  },
  {
    pergunta: "A proteção de dados tem como objetivo impedir o acesso dos próprios titulares aos seus dados.",
    resposta: false
  },
  {
    pergunta: "O uso de Big Data pode gerar preocupações com a privacidade dos usuários.",
    resposta: true
  },
  {
    pergunta: "A privacidade diferencial é uma técnica usada apenas para encriptação de e-mails.",
    resposta: false
  },
  {
    pergunta: "Atividades antes consideradas privadas agora podem ser rastreadas digitalmente.",
    resposta: true
  },
  {
    pergunta: "A pseudonimização permite que os dados sejam reidentificados com informações adicionais.",
    resposta: true
  },
  {
    pergunta: "A ética no uso de dados é dispensável quando se trata de dados anonimizados.",
    resposta: false
  },
  {
    pergunta: "A correlação entre diferentes conjuntos de dados pode reverter processos de anonimização.",
    resposta: true
  },
  {
    pergunta: "A LGPD permite o uso de dados pessoais sem necessidade de consentimento ou transparência.",
    resposta: false
  },
  {
    pergunta: "A transparência no uso de dados contribui para a confiança entre empresas e usuários.",
    resposta: true
  },
  {
    pergunta: "A conformidade com a LGPD é opcional para empresas pequenas.",
    resposta: false
  },
  {
    pergunta: "A privacidade diferencial busca equilibrar a utilidade dos dados com a proteção da privacidade.",
    resposta: true
  },
  {
    pergunta: "Empresas que utilizam Big Data não precisam se preocupar com princípios éticos.",
    resposta: false
  },
  {
    pergunta: "A coleta de dados pode ocorrer sem que os usuários tenham conhecimento claro disso.",
    resposta: true
  },
  {
    pergunta: "A proteção de dados é uma questão legal, técnica e ética no contexto do Big Data.",
    resposta: true
  },
  {
    pergunta: "A coleta de dados em Big Data é uma etapa que pode ser realizada manualmente para grandes volumes de dados.",
    resposta: false
  },
  {
    pergunta: "O Splunk é uma ferramenta de análise de dados de segurança.",
    resposta: true
  },
  {
    pergunta: "Os bancos de dados NoSQL são menos flexíveis que os bancos de dados relacionais.",
    resposta: false
  },
  {
    pergunta: "O Apache Kafka é uma ferramenta de processamento de dados em batch.",
    resposta: false
  },
  {
    pergunta: "O Scrapy pode ser usado para coletar dados de sites dinâmicos.",
    resposta: true
  },
  {
    pergunta: "A ferramenta Import.io é utilizada para coletar dados de fontes web sem necessidade de código.",
    resposta: true
  },
  {
    pergunta: "A coleta de dados em Big Data envolve apenas dados de sensores.",
    resposta: false
  },
  {
    pergunta: "Data warehouses são usados para armazenar dados em tempo real.",
    resposta: false
  },
  {
    pergunta: "A ferramenta Crawly é especializada em desenvolvimento e operação de bots para coleta de dados.",
    resposta: true
  },
  {
    pergunta: "A coleta de dados em Big Data é uma etapa que pode ser ignorada no processo de análise.",
    resposta: false
  },
  {
    pergunta: "O Apache Hadoop é um ecossistema de código aberto para armazenamento e processamento de dados em um ambiente distribuído.",
    resposta: true
  },
  {
    pergunta: "O Splunk é usado principalmente para monitorar logs de sistemas operacionais.",
    resposta: true
  },
  {
    pergunta: "O Big Data envolve apenas dados estruturados e semiestruturados.",
    resposta: false
  },
  {
    pergunta: "Data warehouses são usados para armazenar dados brutos e não processados.",
    resposta: false
  },
  {
    pergunta: "A coleta de dados em Big Data envolve apenas dados gerados por máquinas.",
    resposta: false
  },
  {
    pergunta: "Data lakes são usados para armazenar dados processados e prontos para análise.",
    resposta: false
  },
  {
    pergunta: "Data warehouses são usados para armazenar dados estruturados e processados para uso operacional.",
    resposta: true
  },
  {
    pergunta: "O Apache Kafka é uma ferramenta de streaming de dados em tempo real.",
    resposta: true
  },
  {
    pergunta: "O Scrapy é uma ferramenta de código aberto usada para coletar dados da internet.",
    resposta: true
  },
  {
    pergunta: "A coleta de dados em Big Data envolve apenas dados em tempo real.",
    resposta: false
  },
  {
    pergunta: "O termo Big Data Analytics refere-se aos poderosos softwares que tratam dados estruturados e não estruturados para transformá-los em informações úteis às organizações, permitindo-lhes analisar dados.",
    resposta: true
  },
  {
    pergunta: "Dados coletados de redes sociais não podem ser armazenados, correlacionados e expostos com o uso de análises preditivas.",
    resposta: false
  },
  {
    pergunta: "Uma empresa, ao implementar técnicas e softwares de big data, deu enfoque diferenciado à análise que tem como objetivo mostrar as consequências de determinado evento. Essa análise é do tipo preditiva.",
    resposta: false
  },
  {
    pergunta: "Os fatores críticos de sucesso da análise de Big Data incluem uma sólida infraestrutura de dados, além de ferramentas analíticas e pessoal habilitado para lidar com elas.",
    resposta: true
  },
  {
    pergunta: "O big data analytics difere do business intelligence por analisar o que já existe e o que está por vir, apontando novos caminhos.",
    resposta: true
  },
  {
    pergunta: "A análise de Big Data é uma disciplina que se limita exclusivamente ao uso de dados estruturados, como aqueles encontrados em bancos de dados relacionais tradicionais.",
    resposta: false
  },
  {
    pergunta: "O Apache Hadoop é uma plataforma de software que oferece apenas capacidades de armazenamento de dados em grandes volumes, mas não possui ferramentas para processamento distribuído desses dados.",
    resposta: false
  },
  {
    pergunta: "A velocidade na análise de Big Data refere-se principalmente à rapidez com que os dados são gerados, e não à velocidade com que esses dados são processados e analisados para obter insights.",
    resposta: false
  },
  {
    pergunta: "A variedade de dados em Big Data inclui apenas dados estruturados e semiestruturados.",
    resposta: false
  },
  {
    pergunta: "A veracidade dos dados é um dos 5 Vs do Big Data, referindo-se à confiabilidade e precisão dos dados coletados.",
    resposta: true
  },
  {
    pergunta: "A análise preditiva em Big Data utiliza apenas algoritmos estatísticos tradicionais, sem o uso de técnicas de aprendizado de máquina ou inteligência artificial.",
    resposta: false
  },
  {
    pergunta: "Os bancos de dados NoSQL são mais lentos e menos escaláveis do que os bancos de dados relacionais tradicionais, tornando-os inadequados para aplicações de Big Data.",
    resposta: false
  },
  {
    pergunta: "A integração de dados em Big Data envolve apenas a consolidação de dados estruturados provenientes de diferentes fontes, sem considerar a integração de dados não estruturados.",
    resposta: false
  },
  {
    pergunta: "O processamento de dados na memória aumenta significativamente a velocidade de processamento, mas não é adequado para análises em tempo real devido à limitação de capacidade de memória.",
    resposta: false
  },
  {
    pergunta: "A análise de Big Data é usada principalmente para melhorar a experiência do cliente em plataformas de e-commerce, mas não tem aplicações em outras áreas, como saúde ou finanças.",
    resposta: false
  },
  {
    pergunta: "A mineração de dados é uma técnica usada exclusivamente para identificar padrões em dados estruturados, sem aplicação em dados não estruturados.",
    resposta: false
  },
  {
    pergunta: "Os data lakes armazenam apenas dados estruturados e processados, não sendo adequados para armazenar dados crus ou não processados.",
    resposta: false
  },
  {
    pergunta: "A análise em tempo real de Big Data permite a extração de insights apenas de dados históricos, e não é capaz de processar dados em tempo real para tomar decisões imediatas.",
    resposta: false
  },
  {
    pergunta: "O valor dos dados em Big Data refere-se apenas ao custo de armazenamento e processamento, sem considerar o valor estratégico ou competitivo que esses dados podem oferecer às organizações.",
    resposta: false
  },
  {
    pergunta: "A análise de Big Data é essencialmente uma ferramenta para melhorar a tomada de decisões estratégicas em organizações, mas não tem impacto significativo na operação diária ou na inovação de produtos.",
    resposta: false
  }  
];

let perguntaAtual = 0;
let acertos = 0;
let erros = 0;

const respostasDados = perguntas.map(() => ({ respondido: false, usuarioAcertou: null }));

const numeroPerguntaElemento = document.getElementById("numero-pergunta");
const perguntaElemento = document.getElementById("pergunta");
const indicadorTotalElemento = document.getElementById("indicador-total");
const acertosElemento = document.getElementById("acertos");
const errosElemento = document.getElementById("erros");
const btnVoltar = document.getElementById("btn-voltar");
const btnAvancar = document.getElementById("btn-avancar");
const btnOpcao = document.querySelectorAll(".btn-opcao");
const btnFinalizar = document.getElementById("btn-finalizar");

function exibirPergunta() {
  const perguntaObj = perguntas[perguntaAtual];
  const estado = respostasDados[perguntaAtual];

  numeroPerguntaElemento.textContent = "Pergunta";
  perguntaElemento.textContent = perguntaObj.pergunta;
  indicadorTotalElemento.textContent = `${String(perguntaAtual + 1).padStart(2, '0')} / ${String(perguntas.length).padStart(2, '0')}`;

  btnOpcao.forEach((btn) => {
    btn.disabled = false;
    btn.classList.remove("correta", "errada");

    const valor = btn.dataset.resposta === "true";

    if (estado.respondido) {
      btn.disabled = true;
      if (valor === perguntaObj.resposta) {
        btn.classList.add("correta");
      } else if (valor !== perguntaObj.resposta && !estado.usuarioAcertou) {
        btn.classList.add("errada");
      }
    }
  });
}


function atualizarMarcadores() {
  acertosElemento.textContent = acertos;
  errosElemento.textContent = erros;
}

function verificarResposta(respostaUsuario, botaoClicado) {
  const estado = respostasDados[perguntaAtual];
  if (estado.respondido) return;

  const respostaCorreta = perguntas[perguntaAtual].resposta;

  estado.respondido = true;
  estado.usuarioAcertou = respostaUsuario === respostaCorreta;

  if (estado.usuarioAcertou) {
    acertos++;
    botaoClicado.classList.add("correta");
  } else {
    erros++;
    botaoClicado.classList.add("errada");
    // mostrar qual era a correta
    btnOpcao.forEach((btn) => {
      if (btn.dataset.resposta === respostaCorreta.toString()) {
        btn.classList.add("correta");
      }
    });

  }
  
  btnOpcao.forEach((btn) => btn.disabled = true);
  atualizarMarcadores();
  
  setTimeout(() => {
    if (perguntaAtual < perguntas.length - 1) {
      perguntaAtual++;
      exibirPergunta();
    }
  }, 600);
}

btnVoltar.addEventListener("click", () => {
  if (perguntaAtual > 0) {
    perguntaAtual--;
    exibirPergunta();
  }
});

btnAvancar.addEventListener("click", () => {
  if (perguntaAtual < perguntas.length - 1) {
    perguntaAtual++;
    exibirPergunta();
  }
});

btnFinalizar.addEventListener("click", () => {
  alert(`Quiz finalizado! Você teve ${acertos} acertos e ${erros} erros.`);
});

btnOpcao.forEach((btn) => {
  btn.addEventListener("click", (event) => {
    const respostaUsuario = event.target.dataset.resposta === "true";
    verificarResposta(respostaUsuario, event.target);
  });
});

exibirPergunta();
atualizarMarcadores();
